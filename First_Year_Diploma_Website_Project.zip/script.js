// script.js - Search and form interactions for the Diploma Student Portal

const searchBox = document.getElementById("searchBox");
const searchButton = document.getElementById("searchButton");
const clearButton = document.getElementById("clearButton");
const searchMessage = document.getElementById("searchMessage");
const topicCards = document.querySelectorAll(".topic-card");

function searchTopics() {
  const query = searchBox.value.trim().toLowerCase();
  let matches = 0;

  topicCards.forEach((card) => {
    const found = card.textContent.toLowerCase().includes(query);
    card.style.display = found ? "" : "none";
    if (found) matches++;
  });

  searchMessage.textContent = query
    ? matches + " topic(s) found."
    : "Showing all topics.";
}

searchButton.addEventListener("click", searchTopics);
searchBox.addEventListener("keydown", (event) => {
  if (event.key === "Enter") searchTopics();
});

clearButton.addEventListener("click", () => {
  searchBox.value = "";
  searchTopics();
});

document.getElementById("studentForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const details = {
    name: document.getElementById("studentName").value,
    roll: document.getElementById("rollNumber").value || "Not provided",
    branch: document.getElementById("branch").value || "Not selected",
    year: document.getElementById("year").value,
    college: document.getElementById("college").value || "Not provided"
  };

  const output = document.getElementById("studentOutput");
  output.replaceChildren();

  const heading = document.createElement("h3");
  heading.textContent = "Student Details";
  output.appendChild(heading);

  Object.entries(details).forEach(([key, value]) => {
    const line = document.createElement("p");
    line.textContent = key.charAt(0).toUpperCase() + key.slice(1) + ": " + value;
    output.appendChild(line);
  });
});

document.getElementById("contactForm").addEventListener("submit", (event) => {
  event.preventDefault();
  document.getElementById("contactStatus").textContent =
    "Thank you! This is a demo form. Your message has not been sent or stored.";
  event.target.reset();
});
